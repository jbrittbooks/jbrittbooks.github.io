<?PHP
	$reserved_filenames = Array('cms','cmsimages','cmsfiles','.','..') ;
?>