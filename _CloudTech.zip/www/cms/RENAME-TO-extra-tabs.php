<?PHP
	addCustomTab('Ben Test', 'settings.php') ;
?>