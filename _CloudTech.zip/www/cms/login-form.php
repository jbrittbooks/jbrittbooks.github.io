<?PHP 
	header('Content-type: text/html; charset=UTF-8') ;
	$sesh = @session_start() ;
	require 'pre-login.php' ;
	require '../cmsfns.php' ;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-type" value="text/html; charset=UTF-8" />
	<title>
		<?PHP 
			echo translate('Please log in') . ' - ' ;
			if (isset($_SESSION['CMS_Title'])) echo stripslashes($_SESSION['CMS_Title']) ;
		?>
	</title>
	<link href="styles.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" language="javascript" src="core.js"></script>
</head>

<body>

<div id="topbar">
	<div id="titles">
		<div id="cmsTitle"><?PHP echo stripslashes($_SESSION['CMS_Title']) ; ?></div>
		<div id="siteTitle"><img src="images/cms-logo.gif" alt="CMS" width="90" height="36" border="0" /></div>
	</div>
</div>
	
	<div class="login_box">
		<?PHP
			if (isset($_GET['message'])) {
				switch ($_GET['message']) {
					case "loginwrong":
					   echo '<h1 class="errormsg">Login failed</h1>' ;
					   break;
					default:
						echo '<h1>' . translate('Please log in') . '</h1>' ;
						break ;
				}
			}
			else {
				echo '<h1>' . translate('Please log in') . '</h1>' ;
			}
		?>
		<div class="login_inner">
			<div class="login_textarea">
				<form action="login.php" method="post">
					Log in&nbsp; 
					<input type="password" name="user" id="login-field" style="width:8em;" />
					&nbsp;
					<input type="submit" value="Submit" />
				</form>
			</div>
		</div>
	</div>

</html>