<?PHP
	require '../cmsfns.php' ;
 	require 'check-login.php' ;
	
	function full_copy( $source, $target )
    {
        if (is_dir($source )) {
            @mkdir($target );
            $d = dir($source);
            while ( FALSE !== ( $entry = $d->read() ) )
            {
                if ( $entry == '.' || $entry == '..' ) continue ;
                $Entry = $source . '/' . $entry ;           
                if (is_dir($Entry)) {
                    full_copy( $Entry, $target . '/' . $entry ) ;
                    continue;
                }
                copy($Entry, $target . '/' . $entry);
            }
            $d->close();
        }
		else {
            copy( $source, $target );
        }
    }
	
	if (!isset($_GET['pagepath'])) {
		print('error:No new page name passed.') ;
		exit ;
	}
	else {
		$newLivePagePath = pathFromID($_GET['pagepath'] . '.php') ;
		$newPreviewPagePath = getPreviewFileFromLive($newLivePagePath) ;
		$pathToPage = dirname($newLivePagePath) . '/' ;
	}
	
	if (isset($_GET['pt']) && strlen($_GET['pt'])) {
		// Fetch contents of Page Template
		$pt = $_GET['pt'] ;
		if (getFileExtension($pt) != 'php') $pt .= '.php' ;
		$ptLCIFolder = PTSDIR . '/' . stripFileExtension($pt) ;
		$ptContents = @file_get_contents(PTSDIR . '/' . pathFromID($pt)) ;
		if (False === $ptContents) {
			echo 'error: Could not find PT ' . pathFromID($pt) ;
			exit ;
		}
		// Put in the right path to cms/general.php
		// 2nd parameter below is source file path, i.e. relative path from web root to new page...
		$ptContents = correctGeneralInclude($ptContents, $pathToPage) ;
		// Replace any << includes >> with appropriate put() function calls...
		$ptContents = unSimplifyContents($ptContents) ;
	}
	
	// Check page doesn't already exist
	if (is_file($newLivePagePath)) {
		print('error: Page already exists: ' . $newLivePagePath) ;
		exit ;
	}
	
	// Create local page-includes folders
	$includesDirectoryRoot = getLCIRootFolderFromPagePath($newLivePagePath) ;
	$previewIncludesDirectory = $includesDirectoryRoot . '/cms_preview/' ;
	$liveIncludesDirectory = $includesDirectoryRoot . '/cms_live/' ;
	
	// e.g. $includesDirectoryRoot = 'includes/subdir/foo_cms_files'
	// e.g. $ptLCIFolder = 'pagetemplates/pt1'
	
	

	if (!is_dir($includesDirectoryRoot)) {
		if (mkdir($includesDirectoryRoot, 0755) === False) {
			print('error:Couldn\'t create Root Includes folder: ' . pathFromID($includesDirectoryRoot)) ;
			exit ;
		}
		else chmod($includesDirectoryRoot, 0777) ;
	}
	if (isSet($ptContents)) {
		// Need to copy directory over, not make new ones..
		if (!is_dir($previewIncludesDirectory)) {
			if (full_copy(pathFromID($ptLCIFolder), $previewIncludesDirectory) === False) {
				print('error:Couldn\'t copy includes (' . pathFromID($ptLCIFolder) .') to preview location: ' . pathFromID($previewIncludesDirectory)) ;
				exit ;
			}
			else chmod($previewIncludesDirectory, 0755) ;
		}
		if (!is_dir($liveIncludesDirectory)) {
			if (full_copy(pathFromID($ptLCIFolder), $liveIncludesDirectory) === False) {
				print('error:Couldn\'t copy includes (' . pathFromID($ptLCIFolder) .') to preview location: ' . pathFromID($liveIncludesDirectory)) ;
				exit ;
			}
			else chmod($liveIncludesDirectory, 0755) ;
		}
	}
	else {
		// Making a new page from NO TEMPLATE, so create empty folders
		if (!is_dir($previewIncludesDirectory)) {
			if (mkdir($previewIncludesDirectory) === False) {
				print('error:Couldn\'t create new preview includes folder: ' . pathFromID($previewIncludesDirectory)) ;
				exit ;
			}
			else chmod($previewIncludesDirectory, 0755) ;
		}
		if (!is_dir($liveIncludesDirectory)) {
			if (mkdir($liveIncludesDirectory) === False) {
				print('error:Couldn\'t create new preview includes folder: ' . pathFromID($liveIncludesDirectory)) ;
				exit ;
			}
			else chmod($liveIncludesDirectory, 0755) ;
		}
	}


	
	// Create the actual page file...
	$newLiveFileHandle = fopen($newLivePagePath, 'w') ;
	if (False === fwrite($newLiveFileHandle, $ptContents)) {
		fclose($newLiveFileHandle) ;
		print('error:message=couldntcreatenewpage') ;
		exit ;
	}
	chmod($newLivePagePath, 0644) ;
	fclose($newLiveFileHandle) ;
	
	// Create the preview copy
	$newPreviewFileHandle = fopen($newPreviewPagePath, 'w') ;
	if (False === fwrite($newPreviewFileHandle, $ptContents)) {
		fclose($newPreviewFileHandle) ;
		print('error:message=couldntcreatenewpage') ;
		exit ;
	}
	chmod($newPreviewPagePath, 0644) ;
	fclose($newPreviewFileHandle) ;
	
	/* 
		Return path of new Page to AJAX function.....
	*/
	if (!isSet($_GET['suppress_output'])) print($newLivePagePath) ;
?>
