<?PHP $pathToRoot=''; include_once("general.php") ; ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Jeanetta Britt - Award Winning Author</title>
<meta name="description" content="Jeanetta Britt's novels are filled with juicy drama and edgy suspense, exciting the senses while inspiring the soul. She also writes inspirational poetry to ease the mind and heart." />
<meta name="keywords" content="Jeanetta Britt, Eufaula, AL, Christian author, poems, novels, W.O.O.F., Women, Flittin and Flyin"/>
<meta name="google-site-verification" content="1I3B9Di937YFCh876p2zRwe2ICCPWvVA6R0NL2VNc1w" />
<link rel="stylesheet" type="text/css" media="screen" href="style.css" />
<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-20559146-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<style type="text/css">
#apDiv1 {
	position:absolute;
	width:500px;
	height:160px;
	z-index:1;
	left: -182px;
	top: 4px;
	background-image: url(images/logo2.png);
}
#butterfly {
	position:absolute;
	width:199px;
	height:200px;
	z-index:1;
	left: 808px;
	top: 141px;
	background-image: url(images/butterflysm.png);
}
#apDiv3 {
	position:absolute;
	width:161px;
	height:26px;
	z-index:2;
	left: 252px;
	top: 243px;
	color: #FC3;
	font-size: 14px;
	font-weight: bold;
}
a:link {
	color: #3c465b;
}
a:visited {
	color: #3c465b;
}
.synopsistitle {
	font-weight: bold;
	text-align: center;
}
.home-poem {
	text-align: center;

}
.home-poem-center {
	text-align: center;
	font-weight: bold;
}
#apDiv2 {
	position:absolute;
	width:147px;
	height:115px;
	z-index:2;
	left: 660px;
	top: 172px;
}
.red {
	color: #D91E29;
}
</style>
</head>

<body>
<div id="wrap"><!-- start wrap -->
	<div id="header"> <!-- start header -->
	  <div id="apDiv1"></div>
	  <div id="navigation"><!-- start navigation -->
<ul>
            	<li><a href="index.html" class="current">Home</a></li>
                <li><a href="about.html">Author</a></li>
                <li><a href="novels.html">Novels</a></li>
<li><a href="poems.html">Poems</a></li>
                <li><a href="order.html">Order Now</a></li>
                <li><a href="http://jbrittbooks.blogspot.com/" class="last">Blog</a></li>
                <li><a href="https://docs.google.com/spreadsheet/viewform?formkey=dG9lMGk2MUw3d1pyZkRZQnY3Y09sVEE6MQ" class="last">Contact</a></li>
                
        </ul><!-- end navigation -->
</div>
        <!-- start slogan -->
        <p id="sloganOne">&quot;Love...bears all things, believes all things, hopes all</p>
         <p id="sloganTwo">
        things, endures all things. Love never fails.&quot;
     </p>
         <div id="apDiv3">I Corinthians 13:7-8</div>
        <!-- end slogan -->
  </div> <!-- end header -->
  <div id="content" class="wrapper"><!-- content -->
  		<div id="contentLeft"><!-- start contentLeft -->
       	  <h2>New Releases</h2>
                        <img src="images/woof.png" alt="image1" class="imageBorder imageLeft" />
                        <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"><span class="red">Author/Poet  Jeanetta Britt fires up the drama once again-- keeping it  funny; keeping it real!</span>
                        <p>
  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">  <span class="synopsistitle">W.O.O.F. (Women of Overcoming Faith)</span> ---After a  tragic incident involving her precious daughter, Mother Brown is led  to start a new single&rsquo;s ministry at Overcoming Faith  Church--W.O.O.F.  These young &ldquo;Women of Overcoming Faith&rdquo; will  ban together to keep the <em>wolf</em> at the door through service and celibacy, and by following the 
  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">&ldquo;one  another&rdquo; scriptures in the Bible. You know them: Love one another;  Serve one another; Be kind to one another; <em>blah,  blah, blah</em>.</p>
<p align="justify">But as you  can imagine, their good intentions run into some <em>big-bad</em> opposition...  <a href="novels.html#woof" class="readMore">read more »</a><a href="novels.html"></a></p>
<p><img src="images/flittin.png" alt="flittin" class="imageBorder imageRight" /></p>
<p class="home-poem"><br />
  <span class="home-poem-center">Flittin' &amp; Flyin'--- <br />
  Poems on death, birth &amp; life</span></p>
<p class="home-poem">&quot;Grab Hold!&quot;<br />
  <br />
  We  used to <br />
  Hold  hands<br />
  Without  being asked<br />
  To  do so<br />
  Ring  games <br />
  Prayer  circles<br />
  Friends  holding hands<br />
  Skipping</p>
<p class="home-poem"><a href="poems.html#flittin" class="readMore">read more »</a></p>
<h2>More Novels &amp; Poems</h2>
                        <div class="services wrapper">
                       	  <div class="serviceHomeOne">
                           	<h3>Novels</h3>
                           	  <img src="images/image2.jpg" alt="image2"/>
                            <p><a href="novels.html" class="readMore">read more »</a></p>
</div>
                            
                          <div class="serviceHomeTwo">
                           	<h3>Poems</h3>
                           	  <img src="images/image3.jpg" alt="image2" />
                              <p><a href="poems.html" class="readMore">read more »</a></p>
</div>
                            
                        </div>
        
        </div><!-- end contentLeft -->
  		<div id="contentRight"><!-- start contentRight -->
        		<!-- start news -->
              	<h2>Latest News</h2>
                <div class="latestNews">
                  <p class="teaser"><iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FJBrittBooks%2F189877594419236&amp;width=250&amp;colorscheme=light&amp;show_faces=false&amp;border_color&amp;stream=true&amp;header=true&amp;height=427" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:250px; height:427px;" allowTransparency="true"></iframe></p>
<p class="teaser"><script src="https://widgets.twimg.com/j/2/widget.js"></script>
<script>
new TWTR.Widget({
  version: 2,
  type: 'profile',
  rpp: 4,
  interval: 30000,
  width: 'auto',
  height: 300,
  theme: {
    shell: {
      background: '#e4edf2',
      color: '#000000'
    },
    tweets: {
      background: '#ffffff',
      color: '#000000',
      links: '#0f8fff'
    }
  },
  features: {
    scrollbar: true,
    loop: false,
    live: false,
    hashtags: true,
    timestamp: true,
    avatars: true,
    behavior: 'all'
  }
}).render().setUser('jbrittbooks').start();
</script></p>
                </div>

                <!-- end news -->
                
        <!-- start Testimonials --></div><!-- end contentRight -->
  </div><!-- end content -->
  
  <!-- start footer -->
   <div id="footer" class="wrapper">
  <p class="copyright">
  © 2011 JBrittBooks &nbsp;|&nbsp; Designed by Tsopei Ink</p>
  <div class="footerMenu"><a href="index.html">Home</a>  &nbsp;|&nbsp;  <a href="about.html">Author</a> &nbsp;|&nbsp;  <a href="novels.html">Novels</a>  &nbsp;|&nbsp;  <a href="poems.html">Poems</a>  &nbsp;|&nbsp;<a href="order.html">Order Now</a>&nbsp;|&nbsp;  <a href="http://brittbooks.blogspot.com/">Blog</a>  &nbsp;|&nbsp;  <a href="https://docs.google.com/spreadsheet/viewform?formkey=dG9lMGk2MUw3d1pyZkRZQnY3Y09sVEE6MQ">Contact</a></div>
  </div>
  <!-- end footer -->
<div id="butterfly"></div>  
</div>
<div id="apDiv2"><img src="images/shiph.png" width="144" height="143" alt="Free Shipping on All Orders" /></div>

<!-- end wrap -->

</body>
</html>
